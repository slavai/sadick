<?php

/******************************************************************************/
/******************************************************************************/

require_once(plugin_dir_path(__FILE__).'define.php');

require_once(PLUGIN_THEME_STYLE_CLASS_PATH.'TS.File.class.php');
require_once(PLUGIN_THEME_STYLE_CLASS_PATH.'TS.Include.class.php');

TSInclude::includeFileFromDir(PLUGIN_THEME_STYLE_CLASS_PATH);

/******************************************************************************/
/******************************************************************************/